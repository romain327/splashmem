#!/bin/bash

./splash ./pl/p1.so ./pl/p2.so ./pl/p3.so ./pl/p4.so

